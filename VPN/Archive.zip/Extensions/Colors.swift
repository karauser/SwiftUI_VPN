//
//  Colors.swift
//  VPN
//
//  Created by Sergey on 16.04.2022.
//


import SwiftUI


extension Color {
    public static let powerButtonColor = Color(UIColor(red: 161.0/255.0, green: 87.0/255.0, blue: 255.0/255.0, alpha: 0.75))
    
    public static let gradientButtonColor = RadialGradient(gradient: .powerButtonGradient, center: .center, startRadius: 5, endRadius: 120)
    
}




extension Gradient {
    public static let powerButtonGradient = Gradient(colors: [Color(UIColor(.powerButtonColor)), Color(UIColor(.white))])
    
    public static let defaultButtonGradient = Gradient(colors: [Color(UIColor(.black)), Color(UIColor(.gray))])
}

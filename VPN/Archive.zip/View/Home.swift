//
//  Home.swift
//  VPN
//
//  Created by Sergey on 13.04.2022.
//

import SwiftUI


struct Home: View {
    @State private var isConnected = false
    @State private var animationAmount = 1.0
    @State private var isRotateTop = false
    @State private var isPowerVPNButtonOn = false
    @State private var brandGradient = Gradient(colors: [Color(.systemTeal), Color(.systemPurple)])

    
    
    
    var body: some View {
        VStack {
            HStack {
                Button { } label: {
                    Image("Logo")
                        .resizable()
                        .frame(width: 60.0, height: 9.0)
                        .font(.title2)
                        .padding(12)
                }
                Spacer()
                Button {
                } label: {
                    VStack(alignment: .center, spacing: 5) {
                    Rectangle()
                        .frame(width: 35, height: 2)
                        .cornerRadius(4)
                       
                        .rotationEffect(
                        .degrees(isRotateTop ? 12 : 0),
                        anchor: .leading)
                
                    Rectangle()
                        .frame(width: 35, height: 2)
                        .cornerRadius(4)
                        
                        .rotationEffect(
                        .degrees(isRotateTop ? -12 : 0),
                        anchor: .leading)
                    }.animation(Animation
                                    .interpolatingSpring(stiffness: 100, damping: 10), value: isRotateTop)
                        .onTapGesture {
                            self.isRotateTop.toggle()

                        }
                }
            }

               
                        .foregroundColor(.white)
            
            // PowerButton inizialize
            Button {
                
            } label: {
                Image(systemName: "power")
                    .font(.system(size: 45, weight: .medium))
                    .foregroundColor(isPowerVPNButtonOn ? .white : .gray)
                    .clipShape(Circle())
                    .overlay(
                    Image("ring3")
                        .scaleEffect(isPowerVPNButtonOn ? animationAmount : 0)
                        .opacity(2 - animationAmount)
                        .animation(Animation.easeInOut(duration: 2.5)
                                    .repeatCount(isPowerVPNButtonOn ? 10000 : 1, autoreverses: false),
                    value: animationAmount))
                    .onTapGesture {
                                                animationAmount = 2
                        self.isPowerVPNButtonOn.toggle()
                        
                       
                    }
                                            
                    
        }
            // Frame
            .frame(width: 130, height: 130)
            .background(
            
                ZStack {
                    Circle()
                        .fill(
                            isPowerVPNButtonOn ? RadialGradient(gradient: .powerButtonGradient, center: .center, startRadius: 5, endRadius: 300) : RadialGradient(gradient: .defaultButtonGradient, center: .center, startRadius: 5, endRadius: 200)
                        )
//                        .foregroundColor(Color(RadialGradient(gradient: .powerButtonGradient, center: .center, startRadius: 5, endRadius: 150) as! CGColor))
                }
                        
            )
            .padding(.top, 100)
    }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            .background(
            LinearGradient(colors: [
                .black, .white
                
            ], startPoint: .top, endPoint: .bottom)
           
        )
    }
}

    
    
    
    
    //View Builder
@ViewBuilder

    func powerButton() -> some View {
        
        
        }
                
        
struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
